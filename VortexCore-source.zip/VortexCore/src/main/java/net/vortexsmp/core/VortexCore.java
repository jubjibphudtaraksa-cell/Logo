package net.vortexsmp.core;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.sound.Sound;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.server.ServerListPingEvent;
import org.bukkit.util.CachedServerIcon;
import java.io.File;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.List;

public final class VortexCore extends JavaPlugin implements Listener {

    private final MiniMessage mm = MiniMessage.miniMessage();
    private BossBar bossBar;
    private BukkitTask task;
    private CachedServerIcon icon;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        setup();
        getLogger().info("Vortex SMP core enabled.");
    }

    @Override
    public void onDisable() {
        teardown();
    }

    private void teardown() {
        if (task != null) task.cancel();
        task = null;
        if (bossBar != null) {
            for (Player p : Bukkit.getOnlinePlayers()) p.hideBossBar(bossBar);
        }
        bossBar = null;
    }

    private void setup() {
        teardown();
        var cfg = getConfig();

        icon = null;
        if (cfg.getBoolean("motd.use-icon", true)) {
            File f = new File(getDataFolder(), "server-icon.png");
            if (!f.exists()) saveResource("server-icon.png", false);
            try {
                icon = Bukkit.loadServerIcon(f);
            } catch (Exception ex) {
                getLogger().warning("โหลด server-icon.png ไม่ได้ (ต้องเป็น PNG 64x64): " + ex.getMessage());
            }
        }

        if (cfg.getBoolean("bossbar.enabled", true)) {
            BossBar.Color color = parseEnum(BossBar.Color.class, cfg.getString("bossbar.color"), BossBar.Color.PURPLE);
            BossBar.Overlay overlay = parseEnum(BossBar.Overlay.class, cfg.getString("bossbar.overlay"), BossBar.Overlay.PROGRESS);
            bossBar = BossBar.bossBar(Component.empty(), 1f, color, overlay);
        }

        long period = Math.max(1, cfg.getInt("tab.update-seconds", 5)) * 20L;
        task = Bukkit.getScheduler().runTaskTimer(this, this::refreshAll, 20L, period);
        refreshAll();
    }

    private void refreshAll() {
        for (Player p : Bukkit.getOnlinePlayers()) refresh(p);
    }

    private void refresh(Player p) {
        var cfg = getConfig();
        if (cfg.getBoolean("tab.enabled", true)) {
            p.sendPlayerListHeaderAndFooter(
                    parse(String.join("<newline>", cfg.getStringList("tab.header")), p),
                    parse(String.join("<newline>", cfg.getStringList("tab.footer")), p));
        }
        if (bossBar != null) {
            bossBar.name(parse(cfg.getString("bossbar.text", ""), p));
            p.showBossBar(bossBar);
        }
    }

    private Component parse(String text, Player p) {
        return mm.deserialize(text, TagResolver.resolver(
                Placeholder.unparsed("online", String.valueOf(Bukkit.getOnlinePlayers().size())),
                Placeholder.unparsed("max", String.valueOf(Bukkit.getMaxPlayers())),
                Placeholder.unparsed("player", p == null ? "" : p.getName())));
    }

    private static <E extends Enum<E>> E parseEnum(Class<E> type, String name, E def) {
        if (name == null) return def;
        try {
            return Enum.valueOf(type, name.toUpperCase());
        } catch (IllegalArgumentException e) {
            return def;
        }
    }

    @EventHandler
    public void onPing(ServerListPingEvent e) {
        var cfg = getConfig();
        if (icon != null) e.setServerIcon(icon);
        if (!cfg.getBoolean("motd.enabled", true)) return;
        e.motd(mm.deserialize(cfg.getString("motd.line1", ""))
                .append(Component.newline())
                .append(mm.deserialize(cfg.getString("motd.line2", ""))));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        var cfg = getConfig();

        String jm = cfg.getString("join-message", "");
        e.joinMessage(jm.isEmpty() ? null : parse(jm, p));

        if (cfg.getBoolean("join-title.enabled", true)) {
            p.showTitle(Title.title(
                    parse(cfg.getString("join-title.title", ""), p),
                    parse(cfg.getString("join-title.subtitle", ""), p),
                    Title.Times.times(
                            Duration.ofMillis(cfg.getInt("join-title.fade-in", 10) * 50L),
                            Duration.ofMillis(cfg.getInt("join-title.stay", 70) * 50L),
                            Duration.ofMillis(cfg.getInt("join-title.fade-out", 20) * 50L))));
            String snd = cfg.getString("join-title.sound", "");
            if (!snd.isEmpty()) {
                try {
                    p.playSound(Sound.sound(net.kyori.adventure.key.Key.key(snd), Sound.Source.MASTER,
                            (float) cfg.getDouble("join-title.sound-volume", 0.6), 1f));
                } catch (Exception ignored) { }
            }
        }
        refresh(p);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        String qm = getConfig().getString("quit-message", "");
        e.quitMessage(qm.isEmpty() ? null : parse(qm, e.getPlayer()));
        if (bossBar != null) e.getPlayer().hideBossBar(bossBar);
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!s.hasPermission("vortexcore.admin")) {
            s.sendMessage(parse(getConfig().getString("messages.no-permission", ""), null));
            return true;
        }
        if (a.length == 1 && a[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            setup();
            s.sendMessage(parse(getConfig().getString("messages.reloaded", ""), null));
            return true;
        }
        s.sendMessage(mm.deserialize("<gold>/vortex reload"));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        return a.length == 1 ? List.of("reload") : List.of();
    }
}
