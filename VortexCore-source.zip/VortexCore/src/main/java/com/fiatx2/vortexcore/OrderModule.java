package com.fiatx2.vortexcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * /order — ออเดอร์รับซื้อระหว่างผู้เล่น
 * ผู้สั่งตั้งไอเทม/จำนวน/ราคาต่อชิ้น ระบบกันเงินไว้ล่วงหน้า (escrow)
 * ผู้เล่นคนอื่นคลิกออเดอร์เพื่อส่งของและรับเงินทันที ของที่ส่งจะรอที่ /order claim ของผู้สั่ง
 */
public final class OrderModule implements CommandExecutor, TabCompleter, Listener {

    private static final class Order {
        long id;
        UUID owner;
        String ownerName;
        Material mat;
        int remaining;
        long price; // cents ต่อชิ้น
        long created;
    }

    private enum Type { BROWSE, MY }

    private static final class Holder implements InventoryHolder {
        final Type type;
        final int page;
        final Map<Integer, Long> ids = new LinkedHashMap<>();
        Inventory inv;

        Holder(Type type, int page) {
            this.type = type;
            this.page = page;
        }

        @Override
        public @NotNull Inventory getInventory() { return inv; }
    }

    private static final int PAGE = 45;

    private final VortexCore plugin;
    private final EconomyManager eco;
    private final File file;
    private final Map<Long, Order> orders = new LinkedHashMap<>();
    private final Map<UUID, Map<Material, Integer>> claims = new LinkedHashMap<>();
    private long nextId = 1;

    private final int maxOrders;
    private final int maxAmount;
    private final double taxPercent;

    public OrderModule(VortexCore plugin, EconomyManager eco) {
        this.plugin = plugin;
        this.eco = eco;
        plugin.getDataFolder().mkdirs();
        this.file = new File(plugin.getDataFolder(), "orders.yml");
        ConfigurationSection c = plugin.getConfig().getConfigurationSection("order");
        this.maxOrders = c == null ? 5 : c.getInt("max-per-player", 5);
        this.maxAmount = c == null ? 2304 : c.getInt("max-amount", 2304);
        this.taxPercent = c == null ? 0.0 : c.getDouble("fill-tax-percent", 0.0);
        load();
    }

    public void shutdown() {
        save();
    }

    // ------------------------------------------------------------ data

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        nextId = y.getLong("next-id", 1);
        ConfigurationSection os = y.getConfigurationSection("orders");
        if (os != null) {
            for (String k : os.getKeys(false)) {
                ConfigurationSection s = os.getConfigurationSection(k);
                if (s == null) continue;
                Order o = new Order();
                try {
                    o.id = Long.parseLong(k);
                    o.owner = UUID.fromString(s.getString("owner", ""));
                } catch (IllegalArgumentException ex) {
                    continue;
                }
                o.mat = Material.matchMaterial(s.getString("material", ""));
                if (o.mat == null) continue;
                o.ownerName = s.getString("owner-name", "?");
                o.remaining = s.getInt("remaining");
                o.price = s.getLong("price");
                o.created = s.getLong("created");
                if (o.remaining <= 0 || o.price <= 0) continue;
                orders.put(o.id, o);
                nextId = Math.max(nextId, o.id + 1);
            }
        }
        ConfigurationSection cs = y.getConfigurationSection("claims");
        if (cs != null) {
            for (String k : cs.getKeys(false)) {
                try {
                    UUID id = UUID.fromString(k);
                    ConfigurationSection s = cs.getConfigurationSection(k);
                    if (s == null) continue;
                    Map<Material, Integer> m = new LinkedHashMap<>();
                    for (String mk : s.getKeys(false)) {
                        Material mat = Material.matchMaterial(mk);
                        int n = s.getInt(mk);
                        if (mat != null && n > 0) m.put(mat, n);
                    }
                    if (!m.isEmpty()) claims.put(id, m);
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("next-id", nextId);
        for (Order o : orders.values()) {
            String b = "orders." + o.id;
            y.set(b + ".owner", o.owner.toString());
            y.set(b + ".owner-name", o.ownerName);
            y.set(b + ".material", o.mat.name());
            y.set(b + ".remaining", o.remaining);
            y.set(b + ".price", o.price);
            y.set(b + ".created", o.created);
        }
        for (Map.Entry<UUID, Map<Material, Integer>> e : claims.entrySet()) {
            for (Map.Entry<Material, Integer> m : e.getValue().entrySet()) {
                if (m.getValue() > 0) y.set("claims." + e.getKey() + "." + m.getKey().name(), m.getValue());
            }
        }
        try {
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("orders.yml save failed: " + ex.getMessage());
        }
    }

    private int countOf(UUID id) {
        int n = 0;
        for (Order o : orders.values()) if (o.owner.equals(id)) n++;
        return n;
    }

    private int claimCount(UUID id) {
        Map<Material, Integer> m = claims.get(id);
        if (m == null) return 0;
        int n = 0;
        for (int v : m.values()) n += v;
        return n;
    }

    private List<Order> all() {
        List<Order> out = new ArrayList<>(orders.values());
        out.sort(Comparator.comparingLong((Order o) -> o.price).reversed().thenComparingLong(o -> o.id));
        return out;
    }

    private static int have(Player p, Material m) {
        int n = 0;
        for (ItemStack it : p.getInventory().getStorageContents()) {
            if (it != null && it.getType() == m && !it.hasItemMeta()) n += it.getAmount();
        }
        return n;
    }

    private static void take(Player p, Material m, int amount) {
        var inv = p.getInventory();
        ItemStack[] c = inv.getStorageContents();
        int remove = amount;
        for (int i = 0; i < c.length && remove > 0; i++) {
            ItemStack it = c[i];
            if (it == null || it.getType() != m || it.hasItemMeta()) continue;
            int t = Math.min(remove, it.getAmount());
            remove -= t;
            if (t == it.getAmount()) {
                inv.setItem(i, null);
            } else {
                ItemStack rest = it.clone();
                rest.setAmount(it.getAmount() - t);
                inv.setItem(i, rest);
            }
        }
    }

    // ------------------------------------------------------------ command

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("ใช้ได้เฉพาะผู้เล่น");
            return true;
        }
        if (!Smp.is(p)) {
            Smp.notHere(p);
            return true;
        }
        if (args.length == 0) {
            openBrowse(p, 0);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "create" -> create(p, args);
            case "my" -> openMy(p);
            case "claim" -> claim(p);
            default -> p.sendMessage(Component.text(
                    "ใช้: /order | /order create <ไอเทม|hand> <จำนวน> <ราคาต่อชิ้น> | /order my | /order claim", NamedTextColor.RED));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) return List.of("create", "my", "claim");
        if (args.length == 2 && args[0].equalsIgnoreCase("create")) {
            String pre = args[1].toLowerCase(Locale.ROOT);
            List<String> out = new ArrayList<>();
            if ("hand".startsWith(pre)) out.add("hand");
            for (Material m : Material.values()) {
                if (out.size() >= 40) break;
                if (!m.isItem() || m.isAir() || m.name().startsWith("LEGACY_")) continue;
                String n = m.name().toLowerCase(Locale.ROOT);
                if (n.startsWith(pre)) out.add(n);
            }
            return out;
        }
        return List.of();
    }

    private void create(Player p, String[] args) {
        if (args.length < 4) {
            p.sendMessage(Component.text("ใช้: /order create <ไอเทม|hand> <จำนวน> <ราคาต่อชิ้น> (ตัวอย่าง: /order create diamond 64 150)", NamedTextColor.RED));
            return;
        }
        Material mat;
        if (args[1].equalsIgnoreCase("hand")) {
            mat = p.getInventory().getItemInMainHand().getType();
        } else {
            mat = Material.matchMaterial(args[1]);
        }
        if (mat == null || mat.isAir() || !mat.isItem()) {
            p.sendMessage(Component.text("ไม่พบไอเทมนี้ (หรือไม่ได้ถือไอเทมในมือ)", NamedTextColor.RED));
            return;
        }
        int amount;
        try {
            amount = Integer.parseInt(args[2]);
        } catch (NumberFormatException ex) {
            amount = -1;
        }
        if (amount < 1 || amount > maxAmount) {
            p.sendMessage(Component.text("จำนวนต้องอยู่ระหว่าง 1 ถึง " + maxAmount, NamedTextColor.RED));
            return;
        }
        Long price = EconomyCommands.parseCents(args[3]);
        if (price == null || price <= 0) {
            p.sendMessage(Component.text("ราคาไม่ถูกต้อง (ตัวอย่าง: 150, 2.5k)", NamedTextColor.RED));
            return;
        }
        long total;
        try {
            total = Math.multiplyExact(price, (long) amount);
        } catch (ArithmeticException ex) {
            p.sendMessage(Component.text("ราคารวมสูงเกินไป", NamedTextColor.RED));
            return;
        }
        if (countOf(p.getUniqueId()) >= maxOrders) {
            p.sendMessage(Component.text("สร้างออเดอร์ได้สูงสุด " + maxOrders + " รายการ", NamedTextColor.RED));
            return;
        }
        EconomyManager.Tx tx = eco.withdraw(p.getUniqueId(), total);
        if (tx != EconomyManager.Tx.SUCCESS) {
            p.sendMessage(Component.text(tx == EconomyManager.Tx.INSUFFICIENT
                    ? "เงินไม่พอ (ต้องกันเงินไว้ " + eco.format(total) + ")" : "สร้างออเดอร์ไม่สำเร็จ", NamedTextColor.RED));
            return;
        }
        Order o = new Order();
        o.id = nextId++;
        o.owner = p.getUniqueId();
        o.ownerName = p.getName();
        o.mat = mat;
        o.remaining = amount;
        o.price = price;
        o.created = System.currentTimeMillis();
        orders.put(o.id, o);
        save();
        p.sendMessage(Component.text("สร้างออเดอร์รับซื้อ ", NamedTextColor.GREEN)
                .append(Component.translatable(mat.translationKey()))
                .append(Component.text(" x" + amount + " ชิ้นละ " + eco.format(price)
                        + " (กันเงินไว้ " + eco.format(total) + ")", NamedTextColor.GREEN)));
    }

    private void claim(Player p) {
        Map<Material, Integer> m = claims.get(p.getUniqueId());
        if (m == null || m.isEmpty()) {
            p.sendMessage(Component.text("ไม่มีของให้รับ", NamedTextColor.GRAY));
            return;
        }
        int given = 0;
        Map<Material, Integer> remain = new LinkedHashMap<>();
        for (Map.Entry<Material, Integer> e : m.entrySet()) {
            int left = e.getValue();
            int max = Math.max(1, e.getKey().getMaxStackSize());
            while (left > 0) {
                int n = Math.min(max, left);
                Map<Integer, ItemStack> rest = p.getInventory().addItem(new ItemStack(e.getKey(), n));
                int notGiven = 0;
                for (ItemStack r : rest.values()) notGiven += r.getAmount();
                given += n - notGiven;
                left -= n;
                if (notGiven > 0) {
                    remain.merge(e.getKey(), notGiven + left, Integer::sum);
                    left = 0;
                }
            }
        }
        if (remain.isEmpty()) claims.remove(p.getUniqueId());
        else claims.put(p.getUniqueId(), remain);
        save();
        p.sendMessage(Component.text("รับของแล้ว " + given + " ชิ้น" + (remain.isEmpty() ? "" : " (ช่องเก็บของเต็ม ยังเหลือค้างอยู่)"),
                remain.isEmpty() ? NamedTextColor.GREEN : NamedTextColor.YELLOW));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (claimCount(p.getUniqueId()) > 0) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (p.isOnline()) p.sendMessage(Component.text("มีของจากออเดอร์ของคุณรอรับอยู่ — พิมพ์ /order claim", NamedTextColor.YELLOW));
            }, 60L);
        }
    }

    // ------------------------------------------------------------ GUI

    private ItemStack display(Order o, Player viewer, boolean mine) {
        ItemStack it = new ItemStack(o.mat, Math.max(1, Math.min(64, o.remaining)));
        var meta = it.getItemMeta();
        List<Component> lore = new ArrayList<>();
        lore.add(GuiUtil.line("ราคา: " + eco.format(o.price) + " / ชิ้น", NamedTextColor.GOLD));
        lore.add(GuiUtil.line("ต้องการอีก: " + o.remaining + " ชิ้น", NamedTextColor.GRAY));
        lore.add(GuiUtil.line("มูลค่ารวม: " + eco.format(o.price * o.remaining), NamedTextColor.GRAY));
        lore.add(GuiUtil.line("ผู้สั่ง: " + o.ownerName, NamedTextColor.GRAY));
        lore.add(Component.empty());
        if (mine) {
            lore.add(GuiUtil.line("คลิกเพื่อยกเลิกและรับเงินคืน", NamedTextColor.RED));
        } else if (o.owner.equals(viewer.getUniqueId())) {
            lore.add(GuiUtil.line("ออเดอร์ของคุณ (ยกเลิกที่ \"ออเดอร์ของฉัน\")", NamedTextColor.YELLOW));
        } else {
            int h = Math.min(have(viewer, o.mat), o.remaining);
            lore.add(GuiUtil.line("คุณมี: " + have(viewer, o.mat) + " ชิ้น", NamedTextColor.GRAY));
            lore.add(GuiUtil.line(h > 0 ? "คลิกเพื่อขาย " + h + " ชิ้น = " + eco.format(o.price * h) : "คุณไม่มีไอเทมนี้",
                    h > 0 ? NamedTextColor.GREEN : NamedTextColor.RED));
        }
        meta.lore(lore);
        it.setItemMeta(meta);
        return it;
    }

    private void openBrowse(Player p, int page) {
        List<Order> list = all();
        int pages = Math.max(1, (list.size() + PAGE - 1) / PAGE);
        page = Math.max(0, Math.min(page, pages - 1));
        Holder h = new Holder(Type.BROWSE, page);
        Inventory inv = Bukkit.createInventory(h, 54, Component.text("Orders (" + (page + 1) + "/" + pages + ")", NamedTextColor.DARK_GREEN));
        h.inv = inv;
        int from = page * PAGE;
        int to = Math.min(list.size(), from + PAGE);
        for (int i = from; i < to; i++) {
            Order o = list.get(i);
            inv.setItem(i - from, display(o, p, false));
            h.ids.put(i - from, o.id);
        }
        if (page > 0) inv.setItem(45, GuiUtil.icon(Material.ARROW, Component.text("ก่อนหน้า", NamedTextColor.YELLOW), null));
        inv.setItem(47, GuiUtil.icon(Material.CHEST, Component.text("ออเดอร์ของฉัน", NamedTextColor.AQUA),
                List.of(GuiUtil.line(countOf(p.getUniqueId()) + "/" + maxOrders + " รายการ", NamedTextColor.GRAY))));
        inv.setItem(49, GuiUtil.icon(Material.GOLD_INGOT, Component.text("ยอดเงิน", NamedTextColor.GOLD),
                List.of(GuiUtil.line(eco.format(eco.cents(p.getUniqueId())), NamedTextColor.WHITE),
                        GuiUtil.line("สร้างออเดอร์: /order create <ไอเทม> <จำนวน> <ราคา/ชิ้น>", NamedTextColor.GRAY))));
        inv.setItem(51, GuiUtil.icon(Material.ENDER_CHEST, Component.text("รับของ", NamedTextColor.GREEN),
                List.of(GuiUtil.line(claimCount(p.getUniqueId()) + " ชิ้น (คลิกเพื่อรับ)", NamedTextColor.GRAY))));
        if (page < pages - 1) inv.setItem(53, GuiUtil.icon(Material.ARROW, Component.text("ถัดไป", NamedTextColor.YELLOW), null));
        p.openInventory(inv);
    }

    private void openMy(Player p) {
        Holder h = new Holder(Type.MY, 0);
        Inventory inv = Bukkit.createInventory(h, 54, Component.text("ออเดอร์ของฉัน", NamedTextColor.DARK_AQUA));
        h.inv = inv;
        int slot = 0;
        for (Order o : orders.values()) {
            if (!o.owner.equals(p.getUniqueId()) || slot >= PAGE) continue;
            inv.setItem(slot, display(o, p, true));
            h.ids.put(slot, o.id);
            slot++;
        }
        inv.setItem(49, GuiUtil.icon(Material.OAK_DOOR, Component.text("กลับ", NamedTextColor.RED), null));
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getSlot();

        if (h.type == Type.BROWSE) {
            if (slot == 45 && h.page > 0) openBrowse(p, h.page - 1);
            else if (slot == 53) openBrowse(p, h.page + 1);
            else if (slot == 47) openMy(p);
            else if (slot == 51) {
                claim(p);
                openBrowse(p, h.page);
            } else if (slot < PAGE) {
                Long id = h.ids.get(slot);
                if (id != null) fill(p, id, h.page);
            }
        } else {
            if (slot == 49) openBrowse(p, 0);
            else if (slot < PAGE) {
                Long id = h.ids.get(slot);
                if (id != null) cancel(p, id);
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    // ------------------------------------------------------------ trade

    private void fill(Player p, long id, int page) {
        Order o = orders.get(id);
        if (o == null) {
            p.sendMessage(Component.text("ออเดอร์นี้เสร็จสิ้นหรือถูกยกเลิกแล้ว", NamedTextColor.RED));
            openBrowse(p, page);
            return;
        }
        if (o.owner.equals(p.getUniqueId())) {
            p.sendMessage(Component.text("นี่คือออเดอร์ของคุณ — ยกเลิกได้ที่ \"ออเดอร์ของฉัน\"", NamedTextColor.YELLOW));
            return;
        }
        int n = Math.min(have(p, o.mat), o.remaining);
        if (n <= 0) {
            p.sendActionBar(Component.text("คุณไม่มีไอเทมนี้ (ไอเทมที่มีชื่อ/เอนชานท์ใช้ไม่ได้)", NamedTextColor.RED));
            return;
        }
        long gross = o.price * n;
        long tax = Math.round(gross * taxPercent / 100.0);
        long credit = Math.max(0, gross - tax);
        if (eco.deposit(p.getUniqueId(), credit) != EconomyManager.Tx.SUCCESS) {
            p.sendActionBar(Component.text("ขายไม่สำเร็จ (เงินเต็มเพดาน)", NamedTextColor.RED));
            return;
        }
        take(p, o.mat, n);
        o.remaining -= n;
        claims.computeIfAbsent(o.owner, k -> new LinkedHashMap<>()).merge(o.mat, n, Integer::sum);
        boolean done = o.remaining <= 0;
        if (done) orders.remove(id);
        save();
        p.sendMessage(Component.text("ขาย ", NamedTextColor.GOLD)
                .append(Component.translatable(o.mat.translationKey()))
                .append(Component.text(" x" + n + " ให้ " + o.ownerName + " ได้รับ +" + eco.format(credit)
                        + (tax > 0 ? " (หักภาษี " + eco.format(tax) + ")" : ""), NamedTextColor.GOLD)));
        Player op = Bukkit.getPlayer(o.owner);
        if (op != null) {
            op.sendMessage(Component.text(p.getName() + " ส่งของให้ออเดอร์ของคุณ " + n + " ชิ้น"
                    + (done ? " (ออเดอร์เสร็จสิ้น)" : "") + " — พิมพ์ /order claim", NamedTextColor.GREEN));
        }
        openBrowse(p, page);
    }

    private void cancel(Player p, long id) {
        Order o = orders.get(id);
        if (o == null || !o.owner.equals(p.getUniqueId())) {
            openMy(p);
            return;
        }
        long refund = o.price * o.remaining;
        if (eco.deposit(p.getUniqueId(), refund) != EconomyManager.Tx.SUCCESS) {
            p.sendMessage(Component.text("คืนเงินไม่สำเร็จ (เงินเต็มเพดาน)", NamedTextColor.RED));
            return;
        }
        orders.remove(id);
        save();
        p.sendMessage(Component.text("ยกเลิกออเดอร์แล้ว คืนเงิน " + eco.format(refund)
                + (claimCount(p.getUniqueId()) > 0 ? " (ของที่ได้รับแล้วรับได้ที่ /order claim)" : ""), NamedTextColor.GREEN));
        openMy(p);
    }
}
