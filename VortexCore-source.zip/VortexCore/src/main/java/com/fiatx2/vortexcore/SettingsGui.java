package com.fiatx2.vortexcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

public class SettingsGui implements Listener {

    private static class Holder implements InventoryHolder {
        Inventory inv;

        @Override
        public @NotNull Inventory getInventory() { return inv; }
    }

    private final JavaPlugin plugin;
    private final File file;
    private final YamlConfiguration data;

    public SettingsGui(JavaPlugin plugin) {
        this.plugin = plugin;
        plugin.getDataFolder().mkdirs();
        this.file = new File(plugin.getDataFolder(), "settings.yml");
        this.data = YamlConfiguration.loadConfiguration(file);
    }

    private boolean nv(UUID id) { return data.getBoolean(id + ".nightvision", false); }

    private void save() {
        try {
            data.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("save failed: " + ex.getMessage());
        }
    }

    public void open(Player p) {
        Holder h = new Holder();
        Inventory inv = Bukkit.createInventory(h, 27, Component.text("ตั้งค่า", NamedTextColor.DARK_GRAY));
        h.inv = inv;
        inv.setItem(13, nvItem(nv(p.getUniqueId())));
        p.openInventory(inv);
    }

    private ItemStack nvItem(boolean on) {
        ItemStack it = new ItemStack(on ? Material.ENDER_EYE : Material.ENDER_PEARL);
        ItemMeta m = it.getItemMeta();
        m.displayName(Component.text("Night Vision", on ? NamedTextColor.GREEN : NamedTextColor.RED, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        m.lore(List.of(
                Component.text("สถานะ: " + (on ? "เปิด" : "ปิด"), on ? NamedTextColor.GREEN : NamedTextColor.RED)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("คลิกเพื่อสลับ", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false)));
        it.setItemMeta(m);
        return it;
    }

    private void apply(Player p) {
        boolean enabled = nv(p.getUniqueId());
        if (enabled && Smp.is(p.getWorld())) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION,
                    PotionEffect.INFINITE_DURATION, 0, false, false, false));
        } else if (!enabled) {
            p.removePotionEffect(PotionEffectType.NIGHT_VISION);
        } else {
            // เปิดตั้งค่าไว้ แต่อยู่นอกโลก smp -> ถอดเฉพาะอันที่เป็น infinite ที่ปลั๊กอินใส่ไว้
            PotionEffect cur = p.getPotionEffect(PotionEffectType.NIGHT_VISION);
            if (cur != null && cur.isInfinite()) p.removePotionEffect(PotionEffectType.NIGHT_VISION);
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getRawSlot() != 13) return;

        boolean now = !nv(p.getUniqueId());
        data.set(p.getUniqueId() + ".nightvision", now);
        save();
        apply(p);
        e.getView().getTopInventory().setItem(13, nvItem(now));
        p.playSound(p.getLocation(), org.bukkit.Sound.UI_BUTTON_CLICK, 1f, 1f);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) { apply(e.getPlayer()); }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) { apply(e.getPlayer()); }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> apply(p));
    }

    // นมล้างเอฟเฟกต์ -> ใส่กลับ
    @EventHandler
    public void onConsume(PlayerItemConsumeEvent e) {
        if (e.getItem().getType() != Material.MILK_BUCKET) return;
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> apply(p));
    }
}
