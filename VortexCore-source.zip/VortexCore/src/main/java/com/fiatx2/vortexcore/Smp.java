package com.fiatx2.vortexcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/** ตัวช่วยเช็คว่าอยู่ในโลกที่กำหนด (ค่าเริ่มต้น "smp" + _nether + _the_end) */
public final class Smp {

    private static String name = "smp";

    private Smp() {}

    public static void init(JavaPlugin plugin) {
        name = plugin.getConfig().getString("world-name", "smp");
    }

    public static String name() {
        return name;
    }

    /** โลก smp (อาจเป็น null ถ้ายังไม่โหลด/ชื่อผิด) */
    public static World world() {
        return Bukkit.getWorld(name);
    }

    /** อยู่ในโลกหลัก (overworld) เท่านั้น เช่น smp */
    public static boolean isMain(World w) {
        return w != null && w.getName().equals(name);
    }

    /** ชื่อโลกทั้ง 3 ที่ระบบทำงาน: smp, smp_nether, smp_the_end */
    public static java.util.List<String> names() {
        return java.util.List.of(name, name + "_nether", name + "_the_end");
    }

    /** โลกทั้ง 3 ที่โหลดอยู่ */
    public static java.util.List<World> worlds() {
        java.util.List<World> list = new java.util.ArrayList<>();
        for (String n : names()) {
            World w = Bukkit.getWorld(n);
            if (w != null) list.add(w);
        }
        return list;
    }

    /** อยู่ในโลกใดโลกหนึ่งใน 3 โลก (smp, smp_nether, smp_the_end) */
    public static boolean is(World w) {
        return w != null && names().contains(w.getName());
    }

    public static boolean is(Location l) {
        return l != null && is(l.getWorld());
    }

    public static boolean is(Entity e) {
        return e != null && is(e.getWorld());
    }

    public static void notHere(Player p) {
        p.sendMessage(Component.text("ใช้ได้เฉพาะในโลก " + String.join(", ", names()) + " เท่านั้น", NamedTextColor.RED));
    }
}
