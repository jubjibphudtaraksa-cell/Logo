package com.fiatx2.vortexcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.inventory.PrepareGrindstoneEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.RayTraceResult;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * เครื่องมือเนเธอร์ไรต์ 3x3 (ย้ายมาจาก ShopModule เดิม) — ซื้อได้จาก /shop ไอเทมที่ใส่ special: hammer
 * คราฟ/ซ่อม/ใส่เอนชานท์ไม่ได้ ใช้ได้ตามจำนวนครั้งที่กำหนด
 * (ใช้ key เดิม "hammer_uses" ค้อนที่ผู้เล่นมีอยู่แล้วจึงยังใช้งานต่อได้)
 */
public final class HammerModule implements Listener {

    private final NamespacedKey usesKey;
    private final Set<UUID> breaking = new HashSet<>();

    public HammerModule(VortexCore plugin) {
        this.usesKey = new NamespacedKey(plugin, "hammer_uses");
    }

    private static Component c(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s).decoration(TextDecoration.ITALIC, false);
    }

    public ItemStack make(Material mat, String name, int uses) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.displayName(c(name != null ? name : "&b&l3x3 " + mat.name()));
        m.setUnbreakable(true);
        m.getPersistentDataContainer().set(usesKey, PersistentDataType.INTEGER, uses);
        it.setItemMeta(m);
        updateLore(it, uses);
        return it;
    }

    private void updateLore(ItemStack it, int uses) {
        ItemMeta m = it.getItemMeta();
        m.getPersistentDataContainer().set(usesKey, PersistentDataType.INTEGER, uses);
        m.lore(List.of(
                c("&7ขุดทีละ &f3x3 &7บล็อก &8(เนเธอร์ไรต์)"),
                c("&7ใช้ได้อีก: &e" + uses + " &7ครั้ง"),
                c("&8นั่งยอง (Shift) = ขุดบล็อกเดียว ไม่เสียจำนวนครั้ง"),
                c("&cคราฟไม่ได้ ซื้อได้อย่างเดียว")));
        it.setItemMeta(m);
    }

    private Integer getUses(ItemStack it) {
        if (it == null || !it.getType().name().startsWith("NETHERITE_") || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(usesKey, PersistentDataType.INTEGER);
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (breaking.contains(p.getUniqueId())) return;
        ItemStack tool = p.getInventory().getItemInMainHand();
        Integer uses = getUses(tool);
        if (uses == null) return;
        if (p.isSneaking()) return;

        Block center = e.getBlock();
        RayTraceResult r = p.rayTraceBlocks(6);
        BlockFace face = (r != null && center.equals(r.getHitBlock()) && r.getHitBlockFace() != null)
                ? r.getHitBlockFace() : p.getFacing().getOppositeFace();

        breaking.add(p.getUniqueId());
        try {
            for (int a = -1; a <= 1; a++) {
                for (int b = -1; b <= 1; b++) {
                    if (a == 0 && b == 0) continue;
                    Block t = face.getModX() != 0 ? center.getRelative(0, a, b)
                            : face.getModY() != 0 ? center.getRelative(a, 0, b)
                            : center.getRelative(a, b, 0);
                    Material type = t.getType();
                    if (type.isAir() || t.isLiquid() || type.getHardness() < 0) continue;
                    if (t.getDestroySpeed(tool) <= 1f) continue;
                    BlockBreakEvent be = new BlockBreakEvent(t, p);
                    if (!be.callEvent()) continue;
                    if (be.isDropItems()) t.breakNaturally(tool);
                    else t.setType(Material.AIR);
                }
            }
        } finally {
            breaking.remove(p.getUniqueId());
        }

        int left = uses - 1;
        if (left <= 0) {
            p.getInventory().setItemInMainHand(null);
            p.playSound(p.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 1f);
            p.sendMessage(c("&6[Shop] &cเครื่องมือ 3x3 ของคุณหมดอายุการใช้งานแล้ว"));
        } else {
            updateLore(tool, left);
            p.getInventory().setItemInMainHand(tool);
            if (left <= 10) p.sendActionBar(c("&cเหลืออีก " + left + " ครั้ง"));
        }
    }

    @EventHandler
    public void onAnvil(PrepareAnvilEvent e) {
        for (ItemStack i : e.getInventory().getContents())
            if (getUses(i) != null) { e.setResult(null); return; }
    }

    @EventHandler
    public void onCraft(PrepareItemCraftEvent e) {
        for (ItemStack i : e.getInventory().getMatrix())
            if (getUses(i) != null) { e.getInventory().setResult(null); return; }
    }

    @EventHandler
    public void onGrind(PrepareGrindstoneEvent e) {
        for (ItemStack i : e.getInventory().getContents())
            if (getUses(i) != null) { e.setResult(null); return; }
    }
}
