package com.fiatx2.vortexcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.persistence.PersistentDataType;

import java.util.EnumMap;
import java.util.Map;

public final class EconomyListener implements Listener {

    private final VortexCore plugin;
    private final EconomyManager eco;
    private final NamespacedKey noRewardKey;

    private final boolean rewardsEnabled;
    private final boolean ignoreSpawnerMobs;
    private final long defaultCents;
    private final Map<EntityType, Long> rewards = new EnumMap<>(EntityType.class);

    public EconomyListener(VortexCore plugin, EconomyManager eco) {
        this.plugin = plugin;
        this.eco = eco;
        this.noRewardKey = new NamespacedKey(plugin, "no_reward");

        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("economy.mob-rewards");
        this.rewardsEnabled = sec != null && sec.getBoolean("enabled", false);
        this.ignoreSpawnerMobs = sec == null || sec.getBoolean("ignore-spawner-mobs", true);
        this.defaultCents = sec == null ? 0L : Math.round(sec.getDouble("default", 0.0) * 100.0);

        ConfigurationSection amounts = sec == null ? null : sec.getConfigurationSection("amounts");
        if (amounts != null) {
            for (String key : amounts.getKeys(false)) {
                try {
                    EntityType type = EntityType.valueOf(key.toUpperCase());
                    rewards.put(type, Math.round(amounts.getDouble(key) * 100.0));
                } catch (IllegalArgumentException e) {
                    plugin.getLogger().warning("economy.mob-rewards.amounts: ไม่รู้จัก EntityType '" + key + "'");
                }
            }
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();
        if (eco.createAccount(p.getUniqueId(), p.getName())) {
            plugin.getLogger().info("Created economy account for " + p.getName());
        }
    }

    /** มอนที่เกิดจากสปอว์นเนอร์/ไข่ จะถูกติดป้ายว่าไม่ให้เงิน (กันฟาร์มเงิน) */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent event) {
        if (!rewardsEnabled || !ignoreSpawnerMobs) return;
        SpawnReason reason = event.getSpawnReason();
        if (reason == SpawnReason.SPAWNER || reason == SpawnReason.SPAWNER_EGG) {
            event.getEntity().getPersistentDataContainer().set(noRewardKey, PersistentDataType.BYTE, (byte) 1);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onKill(EntityDeathEvent event) {
        if (!rewardsEnabled) return;
        LivingEntity dead = event.getEntity();
        if (dead instanceof Player) return;
        Player killer = dead.getKiller();
        if (killer == null || !Smp.is(dead.getWorld())) return;
        if (ignoreSpawnerMobs && dead.getPersistentDataContainer().has(noRewardKey, PersistentDataType.BYTE)) return;

        long cents = rewards.getOrDefault(dead.getType(), defaultCents);
        if (cents <= 0) return;
        if (eco.deposit(killer.getUniqueId(), cents) == EconomyManager.Tx.SUCCESS) {
            killer.sendActionBar(Component.text("+" + eco.format(cents), NamedTextColor.GREEN));
        }
    }
}
