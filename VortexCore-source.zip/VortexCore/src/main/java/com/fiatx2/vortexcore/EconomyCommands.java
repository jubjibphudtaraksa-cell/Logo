package com.fiatx2.vortexcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class EconomyCommands implements CommandExecutor, TabCompleter {

    private static final String ADMIN = "vortexcore.eco.admin";
    private static final String OTHERS = "vortexcore.balance.others";
    private static final double MAX_AMOUNT = 1_000_000_000_000.0;
    private static final int PAGE_SIZE = 10;
    private static final List<String> ECO_SUB = List.of("give", "take", "set", "reset");

    private final EconomyManager eco;

    public EconomyCommands(VortexCore plugin, EconomyManager eco) {
        this.eco = eco;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);

        // คำสั่งผู้เล่นทำงานเฉพาะในโลก smp (แอดมิน /eco ใช้ได้ทุกที่)
        if (!name.equals("eco") && sender instanceof Player p && !Smp.is(p.getWorld())) {
            Smp.notHere(p);
            return true;
        }

        switch (name) {
            case "balance" -> balance(sender, args);
            case "pay" -> pay(sender, args);
            case "baltop" -> baltop(sender, args);
            case "eco" -> admin(sender, args);
            default -> { }
        }
        return true;
    }

    // ---------------------------------------------------------------- /balance

    private void balance(CommandSender sender, String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player p)) {
                msg(sender, "วิธีใช้: /balance <ผู้เล่น>", NamedTextColor.YELLOW);
                return;
            }
            send(sender, Component.text("ยอดเงินของคุณ: ", NamedTextColor.GREEN)
                    .append(Component.text(eco.format(eco.cents(p.getUniqueId())), NamedTextColor.WHITE)));
            return;
        }
        if (!sender.hasPermission(OTHERS)) {
            msg(sender, "คุณไม่มีสิทธิ์ดูยอดเงินของผู้อื่น", NamedTextColor.RED);
            return;
        }
        UUID id = eco.findUuid(args[0]);
        if (id == null || !eco.hasAccount(id)) {
            msg(sender, "ไม่พบผู้เล่นชื่อ " + args[0], NamedTextColor.RED);
            return;
        }
        send(sender, Component.text("ยอดเงินของ " + eco.nameOf(id) + ": ", NamedTextColor.GREEN)
                .append(Component.text(eco.format(eco.cents(id)), NamedTextColor.WHITE)));
    }

    // ---------------------------------------------------------------- /pay

    private void pay(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            msg(sender, "คำสั่งนี้ใช้ได้เฉพาะผู้เล่นในเกม", NamedTextColor.RED);
            return;
        }
        if (args.length != 2) {
            msg(p, "วิธีใช้: /pay <ผู้เล่น> <จำนวน>", NamedTextColor.YELLOW);
            return;
        }
        UUID to = eco.findUuid(args[0]);
        if (to == null || !eco.hasAccount(to)) {
            msg(p, "ไม่พบผู้เล่นชื่อ " + args[0], NamedTextColor.RED);
            return;
        }
        if (to.equals(p.getUniqueId())) {
            msg(p, "โอนเงินให้ตัวเองไม่ได้", NamedTextColor.RED);
            return;
        }
        Long amount = parseCents(args[1]);
        if (amount == null) {
            msg(p, "จำนวนเงินไม่ถูกต้อง", NamedTextColor.RED);
            return;
        }
        if (amount < eco.payMinCents()) {
            msg(p, "โอนขั้นต่ำ " + eco.format(eco.payMinCents()), NamedTextColor.RED);
            return;
        }

        long tax = Math.round(amount * eco.payTaxPercent() / 100.0);
        long credit = amount - tax;
        EconomyManager.Tx r = eco.transfer(p.getUniqueId(), to, amount, credit);
        switch (r) {
            case SUCCESS -> {
                String toName = eco.nameOf(to);
                String taxNote = tax > 0 ? " (ภาษี " + eco.format(tax) + ")" : "";
                msg(p, "โอน " + eco.format(amount) + " ให้ " + toName + " แล้ว" + taxNote, NamedTextColor.GREEN);
                Player target = Bukkit.getPlayer(to);
                if (target != null) {
                    msg(target, "คุณได้รับ " + eco.format(credit) + " จาก " + p.getName(), NamedTextColor.GREEN);
                }
            }
            case INSUFFICIENT -> msg(p, "เงินของคุณไม่พอ (มี " + eco.format(eco.cents(p.getUniqueId())) + ")", NamedTextColor.RED);
            case MAX_BALANCE -> msg(p, "ผู้รับมีเงินเต็มขีดจำกัดแล้ว", NamedTextColor.RED);
            default -> msg(p, "โอนเงินไม่สำเร็จ", NamedTextColor.RED);
        }
    }

    // ---------------------------------------------------------------- /baltop

    private void baltop(CommandSender sender, String[] args) {
        List<Map.Entry<UUID, Long>> top = eco.top();
        int pages = Math.max(1, (top.size() + PAGE_SIZE - 1) / PAGE_SIZE);
        int page = 1;
        if (args.length > 0) {
            try {
                page = Integer.parseInt(args[0]);
            } catch (NumberFormatException e) {
                msg(sender, "วิธีใช้: /baltop [หน้า]", NamedTextColor.YELLOW);
                return;
            }
        }
        page = Math.max(1, Math.min(page, pages));

        send(sender, Component.text("=== อันดับคนรวย (หน้า " + page + "/" + pages + ") ===", NamedTextColor.LIGHT_PURPLE));
        int from = (page - 1) * PAGE_SIZE;
        int to = Math.min(top.size(), from + PAGE_SIZE);
        for (int i = from; i < to; i++) {
            Map.Entry<UUID, Long> e = top.get(i);
            sender.sendMessage(Component.text("#" + (i + 1) + " ", NamedTextColor.GOLD)
                    .append(Component.text(eco.nameOf(e.getKey()), NamedTextColor.AQUA))
                    .append(Component.text(" - ", NamedTextColor.GRAY))
                    .append(Component.text(eco.format(e.getValue()), NamedTextColor.GREEN)));
        }
        if (top.isEmpty()) {
            sender.sendMessage(Component.text("ยังไม่มีข้อมูล", NamedTextColor.GRAY));
        }
    }

    // ---------------------------------------------------------------- /eco (admin)

    private void admin(CommandSender sender, String[] args) {
        if (!sender.hasPermission(ADMIN)) {
            msg(sender, "คำสั่งนี้สำหรับ OP เท่านั้น", NamedTextColor.RED);
            return;
        }
        String sub = args.length > 0 ? args[0].toLowerCase(Locale.ROOT) : "";
        boolean needsAmount = sub.equals("give") || sub.equals("take") || sub.equals("set");
        if (!needsAmount && !sub.equals("reset")) {
            msg(sender, "วิธีใช้: /eco <give|take|set|reset> <ผู้เล่น> [จำนวน]", NamedTextColor.YELLOW);
            return;
        }
        if (args.length < (needsAmount ? 3 : 2)) {
            msg(sender, needsAmount ? "วิธีใช้: /eco " + sub + " <ผู้เล่น> <จำนวน>" : "วิธีใช้: /eco reset <ผู้เล่น>",
                    NamedTextColor.YELLOW);
            return;
        }

        UUID id = eco.findUuid(args[1]);
        if (id == null) {
            msg(sender, "ไม่พบผู้เล่นชื่อ " + args[1], NamedTextColor.RED);
            return;
        }
        // แอดมินสร้างบัญชีให้ผู้เล่นที่เซิร์ฟเวอร์รู้จักแต่ยังไม่เคยมีบัญชีได้
        eco.createAccount(id, Bukkit.getPlayer(id) != null ? Bukkit.getPlayer(id).getName() : null);
        String name = eco.nameOf(id);

        if (sub.equals("reset")) {
            eco.reset(id);
            msg(sender, "รีเซ็ตเงินของ " + name + " เป็น " + eco.format(eco.cents(id)), NamedTextColor.GREEN);
            return;
        }

        Long cents = parseCents(args[2]);
        if (cents == null) {
            msg(sender, "จำนวนเงินไม่ถูกต้อง", NamedTextColor.RED);
            return;
        }
        EconomyManager.Tx r = switch (sub) {
            case "give" -> eco.deposit(id, cents);
            case "take" -> eco.withdraw(id, cents);
            default -> eco.set(id, cents);
        };
        switch (r) {
            case SUCCESS -> msg(sender, "ยอดเงินของ " + name + " ตอนนี้: " + eco.format(eco.cents(id)), NamedTextColor.GREEN);
            case INSUFFICIENT -> msg(sender, name + " มีเงินไม่พอให้หัก (มี " + eco.format(eco.cents(id)) + ")", NamedTextColor.RED);
            case MAX_BALANCE -> msg(sender, "เกินขีดจำกัดยอดเงินสูงสุด", NamedTextColor.RED);
            default -> msg(sender, "ทำรายการไม่สำเร็จ", NamedTextColor.RED);
        }
    }

    // ---------------------------------------------------------------- helpers

    /** รับ 100, 1,500.50, 2k, 1.5m, 1b -> สตางค์ (null ถ้าไม่ถูกต้อง / <= 0 / เกินขีดจำกัด) */
    static Long parseCents(String raw) {
        String s = raw.trim().toLowerCase(Locale.ROOT).replace(",", "");
        double mult = 1.0;
        if (s.endsWith("k")) {
            mult = 1_000.0;
        } else if (s.endsWith("m")) {
            mult = 1_000_000.0;
        } else if (s.endsWith("b")) {
            mult = 1_000_000_000.0;
        }
        if (mult != 1.0) s = s.substring(0, s.length() - 1);
        if (!s.matches("\\d+(\\.\\d+)?")) return null;
        double value;
        try {
            value = Double.parseDouble(s) * mult;
        } catch (NumberFormatException e) {
            return null;
        }
        if (value <= 0.0 || value > MAX_AMOUNT) return null;
        long cents = Math.round(value * 100.0);
        return cents > 0 ? cents : null;
    }

    private static void msg(CommandSender to, String text, NamedTextColor color) {
        send(to, Component.text(text, color));
    }

    private static void send(CommandSender to, Component body) {
        to.sendMessage(Component.text("[Economy] ", NamedTextColor.GOLD).append(body));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        switch (name) {
            case "balance", "pay" -> {
                if (args.length == 1) addPlayers(out, args[0]);
            }
            case "eco" -> {
                if (!sender.hasPermission(ADMIN)) return out;
                if (args.length == 1) {
                    for (String s : ECO_SUB) {
                        if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
                    }
                } else if (args.length == 2) {
                    addPlayers(out, args[1]);
                }
            }
            default -> { }
        }
        return out;
    }

    private static void addPlayers(List<String> out, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (online.getName().toLowerCase(Locale.ROOT).startsWith(p)) out.add(online.getName());
        }
    }
}
