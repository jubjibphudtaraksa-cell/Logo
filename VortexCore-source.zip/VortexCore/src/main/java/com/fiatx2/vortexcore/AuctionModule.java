package com.fiatx2.vortexcore;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** /ah — ตลาดประมูล/ซื้อขายระหว่างผู้เล่น (ราคาตายตัว) เก็บข้อมูลใน auction.yml */
public final class AuctionModule implements CommandExecutor, TabCompleter, Listener {

    private static final class Listing {
        long id;
        UUID seller;
        String sellerName;
        ItemStack item;
        long price;
        long expires;
    }

    private enum Type { MAIN, MY }

    private static final class Holder implements InventoryHolder {
        final Type type;
        final int page;
        final Map<Integer, Long> ids = new LinkedHashMap<>();
        Inventory inv;

        Holder(Type type, int page) {
            this.type = type;
            this.page = page;
        }

        @Override
        public @NotNull Inventory getInventory() { return inv; }
    }

    private static final int PAGE = 45;

    private final VortexCore plugin;
    private final EconomyManager eco;
    private final File file;
    private final Map<Long, Listing> listings = new LinkedHashMap<>();
    private final Map<UUID, List<ItemStack>> claims = new LinkedHashMap<>();
    private long nextId = 1;
    private BukkitTask task;

    private final int maxListings;
    private final long durationMs;
    private final double taxPercent;

    public AuctionModule(VortexCore plugin, EconomyManager eco) {
        this.plugin = plugin;
        this.eco = eco;
        plugin.getDataFolder().mkdirs();
        this.file = new File(plugin.getDataFolder(), "auction.yml");
        ConfigurationSection c = plugin.getConfig().getConfigurationSection("auction");
        this.maxListings = c == null ? 5 : c.getInt("max-listings-per-player", 5);
        this.durationMs = (long) ((c == null ? 48.0 : c.getDouble("duration-hours", 48.0)) * 3_600_000L);
        this.taxPercent = c == null ? 5.0 : c.getDouble("sale-tax-percent", 5.0);
        load();
    }

    public void start() {
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::expire, 1200L, 1200L);
    }

    public void shutdown() {
        if (task != null) task.cancel();
        save();
    }

    // ------------------------------------------------------------ data

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        nextId = y.getLong("next-id", 1);
        ConfigurationSection ls = y.getConfigurationSection("listings");
        if (ls != null) {
            for (String k : ls.getKeys(false)) {
                ConfigurationSection s = ls.getConfigurationSection(k);
                if (s == null) continue;
                ItemStack item = s.getItemStack("item");
                String seller = s.getString("seller");
                if (item == null || seller == null) continue;
                Listing l = new Listing();
                try {
                    l.id = Long.parseLong(k);
                    l.seller = UUID.fromString(seller);
                } catch (IllegalArgumentException ex) {
                    continue;
                }
                l.sellerName = s.getString("seller-name", "?");
                l.item = item;
                l.price = s.getLong("price");
                l.expires = s.getLong("expires");
                listings.put(l.id, l);
                nextId = Math.max(nextId, l.id + 1);
            }
        }
        ConfigurationSection cs = y.getConfigurationSection("claims");
        if (cs != null) {
            for (String k : cs.getKeys(false)) {
                try {
                    UUID id = UUID.fromString(k);
                    List<ItemStack> list = new ArrayList<>();
                    for (Object o : cs.getList(k, List.of())) if (o instanceof ItemStack is) list.add(is);
                    if (!list.isEmpty()) claims.put(id, list);
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("next-id", nextId);
        for (Listing l : listings.values()) {
            String b = "listings." + l.id;
            y.set(b + ".seller", l.seller.toString());
            y.set(b + ".seller-name", l.sellerName);
            y.set(b + ".item", l.item);
            y.set(b + ".price", l.price);
            y.set(b + ".expires", l.expires);
        }
        for (Map.Entry<UUID, List<ItemStack>> e : claims.entrySet()) {
            if (!e.getValue().isEmpty()) y.set("claims." + e.getKey(), e.getValue());
        }
        try {
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("auction.yml save failed: " + ex.getMessage());
        }
    }

    private void expire() {
        long now = System.currentTimeMillis();
        boolean changed = false;
        for (Listing l : new ArrayList<>(listings.values())) {
            if (l.expires > now) continue;
            listings.remove(l.id);
            claims.computeIfAbsent(l.seller, k -> new ArrayList<>()).add(l.item);
            changed = true;
            Player sp = Bukkit.getPlayer(l.seller);
            if (sp != null) sp.sendMessage(Component.text("สินค้าของคุณหมดอายุ — พิมพ์ /ah claim เพื่อรับคืน", NamedTextColor.YELLOW));
        }
        if (changed) save();
    }

    private List<Listing> active() {
        long now = System.currentTimeMillis();
        List<Listing> out = new ArrayList<>();
        for (Listing l : listings.values()) if (l.expires > now) out.add(l);
        out.sort(Comparator.comparingLong((Listing l) -> l.id).reversed());
        return out;
    }

    private int countOf(UUID id) {
        int n = 0;
        for (Listing l : listings.values()) if (l.seller.equals(id)) n++;
        return n;
    }

    private int claimCount(UUID id) {
        List<ItemStack> l = claims.get(id);
        return l == null ? 0 : l.size();
    }

    // ------------------------------------------------------------ command

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("ใช้ได้เฉพาะผู้เล่น");
            return true;
        }
        if (!Smp.is(p)) {
            Smp.notHere(p);
            return true;
        }
        if (args.length == 0) {
            openMain(p, 0);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "sell" -> sell(p, args);
            case "my" -> openMy(p);
            case "claim" -> claim(p);
            default -> p.sendMessage(Component.text("ใช้: /ah | /ah sell <ราคา> [จำนวน] | /ah my | /ah claim", NamedTextColor.RED));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) return List.of("sell", "my", "claim");
        return List.of();
    }

    private void sell(Player p, String[] args) {
        if (args.length < 2) {
            p.sendMessage(Component.text("ใช้: /ah sell <ราคา> [จำนวน] (ถือไอเทมในมือ, ราคารวมทั้งหมด)", NamedTextColor.RED));
            return;
        }
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand.getType() == Material.AIR) {
            p.sendMessage(Component.text("ต้องถือไอเทมที่จะขายไว้ในมือ", NamedTextColor.RED));
            return;
        }
        Long price = EconomyCommands.parseCents(args[1]);
        if (price == null) {
            p.sendMessage(Component.text("ราคาไม่ถูกต้อง (ตัวอย่าง: 500, 2.5k, 1m)", NamedTextColor.RED));
            return;
        }
        int amount = hand.getAmount();
        if (args.length >= 3) {
            try {
                amount = Integer.parseInt(args[2]);
            } catch (NumberFormatException ex) {
                amount = -1;
            }
            if (amount < 1 || amount > hand.getAmount()) {
                p.sendMessage(Component.text("จำนวนไม่ถูกต้อง (คุณถืออยู่ " + hand.getAmount() + " ชิ้น)", NamedTextColor.RED));
                return;
            }
        }
        if (countOf(p.getUniqueId()) >= maxListings) {
            p.sendMessage(Component.text("ลงขายได้สูงสุด " + maxListings + " รายการ", NamedTextColor.RED));
            return;
        }
        Listing l = new Listing();
        l.id = nextId++;
        l.seller = p.getUniqueId();
        l.sellerName = p.getName();
        l.item = hand.clone();
        l.item.setAmount(amount);
        l.price = price;
        l.expires = System.currentTimeMillis() + durationMs;
        if (amount == hand.getAmount()) {
            p.getInventory().setItemInMainHand(null);
        } else {
            hand.setAmount(hand.getAmount() - amount);
            p.getInventory().setItemInMainHand(hand);
        }
        listings.put(l.id, l);
        save();
        p.sendMessage(Component.text("ลงขาย ", NamedTextColor.GREEN)
                .append(l.item.displayName())
                .append(Component.text(" x" + amount + " ราคา " + eco.format(price)
                        + " (อยู่ " + GuiUtil.time(durationMs) + ")", NamedTextColor.GREEN)));
    }

    private void claim(Player p) {
        List<ItemStack> list = claims.get(p.getUniqueId());
        if (list == null || list.isEmpty()) {
            p.sendMessage(Component.text("ไม่มีของให้รับคืน", NamedTextColor.GRAY));
            return;
        }
        List<ItemStack> remain = new ArrayList<>();
        int given = 0;
        for (ItemStack it : list) {
            Map<Integer, ItemStack> rest = p.getInventory().addItem(it);
            if (rest.isEmpty()) given++;
            else remain.addAll(rest.values());
        }
        if (remain.isEmpty()) claims.remove(p.getUniqueId());
        else claims.put(p.getUniqueId(), remain);
        save();
        p.sendMessage(Component.text("รับคืน " + given + " รายการ" + (remain.isEmpty() ? "" : " (ช่องเก็บของเต็ม เหลืออีก " + remain.size() + ")"),
                remain.isEmpty() ? NamedTextColor.GREEN : NamedTextColor.YELLOW));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (claimCount(p.getUniqueId()) > 0) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (p.isOnline()) p.sendMessage(Component.text("คุณมีของรอรับคืนจากตลาด — พิมพ์ /ah claim", NamedTextColor.YELLOW));
            }, 60L);
        }
    }

    // ------------------------------------------------------------ GUI

    private ItemStack display(Listing l, UUID viewer) {
        ItemStack it = l.item.clone();
        var meta = it.getItemMeta();
        List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        lore.add(Component.empty());
        lore.add(GuiUtil.line("ราคา: " + eco.format(l.price), NamedTextColor.GOLD));
        lore.add(GuiUtil.line("ผู้ขาย: " + l.sellerName, NamedTextColor.GRAY));
        lore.add(GuiUtil.line("เหลือเวลา: " + GuiUtil.time(l.expires - System.currentTimeMillis()), NamedTextColor.GRAY));
        lore.add(GuiUtil.line(l.seller.equals(viewer) ? "ของคุณ (ดูที่ \"รายการของฉัน\")" : "คลิกเพื่อซื้อ",
                l.seller.equals(viewer) ? NamedTextColor.YELLOW : NamedTextColor.GREEN));
        meta.lore(lore);
        it.setItemMeta(meta);
        return it;
    }

    private void openMain(Player p, int page) {
        List<Listing> all = active();
        int pages = Math.max(1, (all.size() + PAGE - 1) / PAGE);
        page = Math.max(0, Math.min(page, pages - 1));
        Holder h = new Holder(Type.MAIN, page);
        Inventory inv = Bukkit.createInventory(h, 54,
                Component.text("ตลาด (" + (page + 1) + "/" + pages + ")", NamedTextColor.DARK_GREEN));
        h.inv = inv;
        int from = page * PAGE;
        int to = Math.min(all.size(), from + PAGE);
        for (int i = from; i < to; i++) {
            Listing l = all.get(i);
            inv.setItem(i - from, display(l, p.getUniqueId()));
            h.ids.put(i - from, l.id);
        }
        if (page > 0) inv.setItem(45, GuiUtil.icon(Material.ARROW, Component.text("ก่อนหน้า", NamedTextColor.YELLOW), null));
        inv.setItem(47, GuiUtil.icon(Material.CHEST, Component.text("รายการของฉัน", NamedTextColor.AQUA),
                List.of(GuiUtil.line(countOf(p.getUniqueId()) + "/" + maxListings + " รายการ", NamedTextColor.GRAY))));
        inv.setItem(49, GuiUtil.icon(Material.GOLD_INGOT, Component.text("ยอดเงิน", NamedTextColor.GOLD),
                List.of(GuiUtil.line(eco.format(eco.cents(p.getUniqueId())), NamedTextColor.WHITE),
                        GuiUtil.line("ลงขาย: /ah sell <ราคา> [จำนวน]", NamedTextColor.GRAY),
                        GuiUtil.line("ภาษีขาย " + taxPercent + "%", NamedTextColor.GRAY))));
        int cc = claimCount(p.getUniqueId());
        inv.setItem(51, GuiUtil.icon(Material.ENDER_CHEST, Component.text("รับของคืน", NamedTextColor.GREEN),
                List.of(GuiUtil.line(cc + " รายการ (คลิกเพื่อรับ)", NamedTextColor.GRAY))));
        if (page < pages - 1) inv.setItem(53, GuiUtil.icon(Material.ARROW, Component.text("ถัดไป", NamedTextColor.YELLOW), null));
        p.openInventory(inv);
    }

    private void openMy(Player p) {
        Holder h = new Holder(Type.MY, 0);
        Inventory inv = Bukkit.createInventory(h, 54, Component.text("รายการของฉัน", NamedTextColor.DARK_AQUA));
        h.inv = inv;
        int slot = 0;
        for (Listing l : listings.values()) {
            if (!l.seller.equals(p.getUniqueId()) || slot >= PAGE) continue;
            ItemStack it = display(l, p.getUniqueId());
            var meta = it.getItemMeta();
            List<Component> lore = new ArrayList<>(meta.lore());
            lore.set(lore.size() - 1, GuiUtil.line("คลิกเพื่อยกเลิกและรับของคืน", NamedTextColor.RED));
            meta.lore(lore);
            it.setItemMeta(meta);
            inv.setItem(slot, it);
            h.ids.put(slot, l.id);
            slot++;
        }
        inv.setItem(49, GuiUtil.icon(Material.OAK_DOOR, Component.text("กลับ", NamedTextColor.RED), null));
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
        int slot = e.getSlot();

        if (h.type == Type.MAIN) {
            if (slot == 45 && h.page > 0) openMain(p, h.page - 1);
            else if (slot == 53) openMain(p, h.page + 1);
            else if (slot == 47) openMy(p);
            else if (slot == 51) {
                claim(p);
                openMain(p, h.page);
            } else if (slot < PAGE) {
                Long id = h.ids.get(slot);
                if (id != null) buy(p, id, h.page);
            }
        } else {
            if (slot == 49) openMain(p, 0);
            else if (slot < PAGE) {
                Long id = h.ids.get(slot);
                if (id != null) cancel(p, id);
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }

    // ------------------------------------------------------------ trade

    private void buy(Player p, long id, int page) {
        Listing l = listings.get(id);
        if (l == null || l.expires <= System.currentTimeMillis()) {
            p.sendMessage(Component.text("สินค้านี้ถูกขายไปแล้วหรือหมดอายุ", NamedTextColor.RED));
            openMain(p, page);
            return;
        }
        if (l.seller.equals(p.getUniqueId())) {
            p.sendMessage(Component.text("นี่คือสินค้าของคุณ — ยกเลิกได้ที่ \"รายการของฉัน\"", NamedTextColor.YELLOW));
            return;
        }
        if (p.getInventory().firstEmpty() == -1) {
            p.sendMessage(Component.text("ช่องเก็บของเต็ม", NamedTextColor.RED));
            return;
        }
        long tax = Math.round(l.price * taxPercent / 100.0);
        long credit = Math.max(0, l.price - tax);
        eco.createAccount(l.seller, l.sellerName);
        EconomyManager.Tx tx = eco.transfer(p.getUniqueId(), l.seller, l.price, credit);
        switch (tx) {
            case SUCCESS -> {
                listings.remove(id);
                p.getInventory().addItem(l.item.clone());
                save();
                p.sendMessage(Component.text("ซื้อ ", NamedTextColor.GREEN)
                        .append(l.item.displayName())
                        .append(Component.text(" x" + l.item.getAmount() + " ราคา " + eco.format(l.price), NamedTextColor.GREEN)));
                Player sp = Bukkit.getPlayer(l.seller);
                if (sp != null) {
                    sp.sendMessage(Component.text(p.getName() + " ซื้อสินค้าของคุณ +" + eco.format(credit)
                            + (tax > 0 ? " (หักภาษี " + eco.format(tax) + ")" : ""), NamedTextColor.GOLD));
                }
                openMain(p, page);
            }
            case INSUFFICIENT -> p.sendMessage(Component.text("เงินไม่พอ (ต้องใช้ " + eco.format(l.price) + ")", NamedTextColor.RED));
            case MAX_BALANCE -> p.sendMessage(Component.text("ผู้ขายมีเงินเต็มเพดานแล้ว ซื้อไม่ได้ตอนนี้", NamedTextColor.RED));
            default -> p.sendMessage(Component.text("ซื้อไม่สำเร็จ", NamedTextColor.RED));
        }
    }

    private void cancel(Player p, long id) {
        Listing l = listings.get(id);
        if (l == null || !l.seller.equals(p.getUniqueId())) {
            openMy(p);
            return;
        }
        listings.remove(id);
        Map<Integer, ItemStack> rest = p.getInventory().addItem(l.item.clone());
        if (!rest.isEmpty()) {
            claims.computeIfAbsent(p.getUniqueId(), k -> new ArrayList<>()).addAll(rest.values());
            p.sendMessage(Component.text("ช่องเก็บของเต็ม — เก็บไว้ที่ /ah claim", NamedTextColor.YELLOW));
        }
        save();
        p.sendMessage(Component.text("ยกเลิกการขายแล้ว", NamedTextColor.GREEN));
        openMy(p);
    }
}
