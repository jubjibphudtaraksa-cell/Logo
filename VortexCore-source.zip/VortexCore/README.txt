VortexCore - Paper 1.21.11 (Java 21)

Build:  mvn clean package   -> target/VortexCore-1.0.0.jar
Install: ใส่ jar ใน plugins/
         ใส่ server-files/server-icon.png ไว้โฟลเดอร์เซิร์ฟเวอร์ (ข้าง server.properties)
Config: plugins/VortexCore/config.yml  | /vortex reload
