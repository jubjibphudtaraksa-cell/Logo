VortexCore - Paper 1.21.11 (Java 21)

Build:  mvn clean package   -> target/VortexCore-1.0.0.jar
Install: ใส่ jar ใน plugins/ (ไอคอนเซิร์ฟโหลดอัตโนมัติจาก plugins/VortexCore/server-icon.png)
Config: plugins/VortexCore/config.yml  | /vortex reload
