VortexLogo - Paper 1.21.11 (Java 21)

Build:  mvn clean package   -> target/VortexLogo-1.0.0.jar
Install: ใส่ jar ใน plugins/ (ไอคอนเซิร์ฟโหลดอัตโนมัติจาก plugins/VortexLogo/server-icon.png)
Config: plugins/VortexLogo/config.yml  | /vortexlogo reload
